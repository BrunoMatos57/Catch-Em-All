package oopgame.gameobjects;

import java.awt.Graphics2D;
import java.awt.Image;
import javax.swing.ImageIcon;
import oopgame.gadgets.Time;
import oopgame.screens.ScreenTemplate;

public class Projectile extends GameObject {
    private ScreenTemplate screen;
    private Time time;
    private Image pokeball;
    
    public Projectile(ScreenTemplate screen, int x){
        this.screen = screen;
        this.x = x;
        y = 471;
        pokeball = new ImageIcon("images/balls/pokeball.png").getImage();
        velY = 0;
        WIDTH = pokeball.getWidth(screen);
        HEIGHT = pokeball.getHeight(screen);
        time = new Time();
    }
    
    @Override
    public void tick(double dt){
        if (time.getTime() == 0){
            y += velY*dt;
            if(y < -HEIGHT) hit(); 
        }
        else{
            time.tick(-dt);
            if (time.getTime() < 0){ // tempo a ser balanceado
                reset();
            }
        }
    }
    
    @Override
    public void render(Graphics2D g){ 
        g.drawImage(pokeball, (int)x, (int)y, screen);
    }
    
    public void startMovement(){
        velY = -200;  //o valor em pixels por segundo do projetil
    }
    
    public void hit(){
        time.setTime(0.1);
        y = 1000; //Gambiaraaaaaaaa
    }
    
    public void reset(){ //reseto o projetil pra posição inicial dele
        velY = 0;
        y = 471;
        time.reset();
    }
}
