package oopgame.gameobjects;

import java.awt.Graphics2D;
import java.awt.Image;
import java.util.Random;
import javax.swing.ImageIcon;
import oopgame.screens.ScreenTemplate;

public abstract class Enemy extends GameObject {
    private ScreenTemplate screen;
    private Image pokemon;
    private Image pokemon2;
    private Random rand; 
    private double clk;  // gambiarra pra trocar imagem
    private boolean can; // gambiarra pra trocar imagem
   
    
    public Enemy(String imgName, ScreenTemplate screen){
        this.screen = screen;
        this.pokemon = new ImageIcon("images/pokemon/" + imgName + ".png").getImage();
        this.pokemon2 = new ImageIcon("images/pokemon/" + imgName + "2.png").getImage();
        WIDTH = pokemon.getWidth(screen);
        HEIGHT = pokemon.getHeight(screen);
        this.rand = new Random();
        x = (rand.nextInt(6)+1)*100-50 - WIDTH/2;
        y = -70;
        clk = 0; /// gambiarra pra trocar a imagem
        can = true; ///gambiarra pra trocar a imagem
    }
    
    @Override
    public void tick(double dt) {
        y += velY*dt;
        clock(dt);
    }

    @Override
    public void render(Graphics2D g) {
        if(can)
            g.drawImage(pokemon, (int)x,(int)y, screen);
        else
            g.drawImage(pokemon2,(int)x,(int)y, screen);
    }
    
    public void clock(double dt){ // gambiarra utilizada pra imagem ficar trocando no render enquanto nao usamos sprites
        clk += dt;
        if (clk >= 0.1){
            can = !can;
            clk = 0;
        }
    }
    
    public double getY(){
        return y;
    }
    
    public int getHeight(){
        return HEIGHT;
    }
    
}
