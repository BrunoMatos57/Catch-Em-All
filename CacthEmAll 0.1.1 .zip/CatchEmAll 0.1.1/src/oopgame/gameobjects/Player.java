package oopgame.gameobjects;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.awt.geom.Rectangle2D;


public class Player extends GameObject {
    private int hp;
    private boolean left;
    private boolean right;
    private double tempo;
    
    public Player(){
        x = 270;
        y = 500;
        hp = 5;
        velX = 250;
        WIDTH = 30;
        HEIGHT = 50;
        left = false;
        right = false;
        tempo = 0;
    }
    
    @Override
    public void tick(double dt){
        if(left) x -= velX*dt;
        else if(right) x += velX*dt;
        
        tempo += dt;
    }
    
    @Override
    public void render(Graphics2D g){
        Rectangle2D rect = new Rectangle2D.Double(x,y,WIDTH,HEIGHT);
        g.setColor(Color.black);
        g.fill(rect);
        
    }
    
    
    public void keyPressed(KeyEvent e){
        if(e.getKeyCode() == KeyEvent.VK_LEFT) left = true;
        else if(e.getKeyCode() == KeyEvent.VK_RIGHT) right = true;
    }
    
    public void keyReleased(KeyEvent e){
        if(e.getKeyCode() == KeyEvent.VK_LEFT)left = false;
        if(e.getKeyCode() == KeyEvent.VK_RIGHT)right = false;
    }
    
    public void damage(){  //da dano no hp do player
        hp -= 1;
    }
    
    public boolean isDead(){  //vejo se o player ta morto
        return hp<=0;
    } 
    
    public int getDamageZone(){
        return 460;
    }
    
    public int getHP(){
        return hp;
    }

}
