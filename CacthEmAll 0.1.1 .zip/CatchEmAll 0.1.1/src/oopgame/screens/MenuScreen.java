package oopgame.screens;

import oopgame.screencontrol.ScreenControl;

import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;


public class MenuScreen extends ScreenTemplate {
    private ScreenControl control;
    
    public MenuScreen(ScreenControl control){
        this.control = control;
    }
    
    @Override
    public void loop(double dt){
        repaint();
        tick(dt);
    }
    
    
    @Override
    public void paint(Graphics g) {
        super.paint(g);
        Graphics2D g2d = (Graphics2D) g;
   
        g2d.setFont(new Font("TimesRoman", Font.PLAIN, 50)); 
        g2d.drawString("MenuScreen", 150, 150);
        g2d.setFont(new Font("TimesRoman", Font.PLAIN, 15));
        g2d.drawString("Press 1 to level 1", 210, 200);
        g2d.drawString("Press 2 to level 2", 210, 220);
        g2d.drawString("Press 3 to level 3", 210, 240);
        g2d.drawString("Press 4 to level 4", 210, 260);
        g2d.drawString("Press 5 to level 5", 210, 280);
        g2d.drawString("Press 6 to level 6", 210, 300);
        g2d.drawString("Press 7 to level 7", 210, 320);
        g2d.drawString("Press 8 to level 8", 210, 340);
        g2d.drawString("Press 9 to level 9", 210, 360);
        g2d.drawString("Press 10 to level 10", 210, 380);
        
    }
    
    @Override
    public void tick(double dt) {
    }
    
    @Override
    public void keyDown(KeyEvent e){  //Vejo o input do usuario e mudo a tela de acordo
        if(e.getKeyCode() == KeyEvent.VK_1){
            control.changeGameState(GameState.Level1);
        }else if(e.getKeyCode() == KeyEvent.VK_2){
            control.changeGameState(GameState.Level2);
        }
    }
}
