package oopgame.screens;

import oopgame.gameobjects.*;
import oopgame.screencontrol.ScreenControl;

public class Level2 extends GameBase{
    
     public Level2(ScreenControl control){
        super(control);  
        
        for(int i = 0; i < 1; i++)
            enemyList.add(new EnemyNormal("venussaur", this, EnemyNormal.NORMAL));
    }
     
    @Override
    public void spawnControl(){
        
    }
     
    
}
