package oopgame.gadgets;

public class Sprite {
    
    public Sprite(String pokemon){
        //n funciona
    }
}
