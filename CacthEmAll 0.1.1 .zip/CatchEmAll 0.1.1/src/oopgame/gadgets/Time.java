package oopgame.gadgets;

public class Time { //nao esta sendo utilizado
    private double time;
    
    public Time(){
        time = 0;
    }
    
    public void setTime(double time){
        this.time = time;
    }
    
    public double getTime(){
        return time;
    }
    
    public void reset(){
        time = 0;
    }
    
    public void tick(double dt){
        time += dt;
    }
}
