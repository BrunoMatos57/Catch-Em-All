package oopgame.screens;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.util.Random;
import oopgame.choosers.WaveLV1;
import oopgame.gameobjects.HUD;
import oopgame.screencontrol.ScreenControl;

public class Level1 extends GameBase {
    private Random rand;
    private double spawnTime;
    private HUD hud;
    protected WaveLV1 wave;
    
    
    public Level1(ScreenControl control){
        super(control);
        wave = new WaveLV1(this);
        hud = new HUD(player, wave);
        rand = new Random();
        spawnTime = rand.nextDouble() * 3;
        backGround.setBackGround("blue");
    }
    
    @Override
    public void spawnControl(){
        if (spawnClock > spawnTime){
            if (wave.getWave() == 1){
                enemyList.add(wave.getWave1());
            }
            else if (wave.getWave() == 2){
                enemyList.add(wave.getWave2());
            }
            spawnTime = rand.nextDouble() * 3;
            spawnClock = 0;
        }
    }
    
    @Override
    public void tick(double dt){
        super.tick(dt);
        hud.tick(dt);
    }
    
    @Override
    public void paint(Graphics g){
        super.paint(g);
        Graphics2D g2d = (Graphics2D) g;
        hud.render(g2d);
    }
    
    @Override
    public void keyUp(KeyEvent e){    ///Para teste de spawn
        super.keyUp(e);
        if(e.getKeyCode() == KeyEvent.VK_S)
            spawnTime = 0;
    }
    
}
