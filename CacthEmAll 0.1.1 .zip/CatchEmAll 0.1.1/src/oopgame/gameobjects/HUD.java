package oopgame.gameobjects;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import oopgame.choosers.Wave;
import oopgame.gadgets.Time;

public class HUD {
    Player player;
    Wave wave;
    //double time;
    Time time;
    
    
    public HUD(Player player, Wave wave){
        this.player = player;
        this.wave = wave;
        //time = 0;
        time = new Time();
    }
    
    public void tick(double dt){
        //time += dt;
        time.tick(dt);
    }
    
    public void render(Graphics2D g){
        g.drawLine(0, 460, 600, 460);
        g.setColor(Color.orange);
        for(int i = 0; i < player.getHP(); i++){
            g.fillOval(i*20+10, 10, 20, 20);
        }
        g.setColor(Color.BLACK);
        g.setFont(new Font("TimesRoman", Font.PLAIN, 20)); 
        g.drawString(String.format("%.02f",time.getTime()), 540, 30);
        g.setFont(new Font("TimesRoman", Font.PLAIN, 10)); 
        g.drawString("s - spawn", 540, 60);
        g.drawString("r - restart", 540, 80);
        g.drawString("wave "+ String.valueOf(wave.getWave()), 540, 100);
        
    }
    
    
}
