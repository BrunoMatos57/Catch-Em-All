package oopgame.gameobjects;

import oopgame.screens.ScreenTemplate;

public class EnemyNormal extends Enemy {
    public static final int SLOW = 50;
    public static final int NORMAL = 150;
    public static final int FAST = 300;
    
    public EnemyNormal(String imgName, ScreenTemplate screen, int velocity){
        super(imgName, screen);
        velY = velocity;
    }
}
