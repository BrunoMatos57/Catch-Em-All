package oopgame.gameobjects;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

public abstract class GameObject {
    protected double x, y; // posicao
    protected double velX, velY; // velocidade
    protected int WIDTH;  //largura
    protected int HEIGHT;  //altura
    
    public abstract void tick(double dt);
    public abstract void render(Graphics2D g);
    
    public Rectangle2D getHitbox(){  //Retorna um retangulo para fazer colisão
        return new Rectangle2D.Double(x,y,WIDTH,HEIGHT);
    }
}
