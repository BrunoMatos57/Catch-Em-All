package oopgame.screens;

import oopgame.gameobjects.*;
import oopgame.screencontrol.ScreenControl;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public abstract class GameBase extends ScreenTemplate {
    
    protected ScreenControl control;
    protected Player player;  // Player
    protected List<Enemy> enemyList;  //Lista de inimigos
    protected Projectile[] projectileList;  //Lista de projéteis
    protected double spawnClock;
    protected BackGround backGround;
    
    public GameBase(ScreenControl control){
        this.control = control; //// variavel para controle de gameState
        /////// Criacao dos objetos do jogo /////////
        player = new Player();
        projectileList = new Projectile[6];
        for (int i = 0; i < 6; i++)
            projectileList[i] = new Projectile(this, 35 + 100*i);
        enemyList = new CopyOnWriteArrayList<>(); // Quem decide quais inimigos serao colocdos eh o level
        ////////////////////////////////////////////
        spawnClock = 0;
        backGround = new BackGround(this);
    }
    
    @Override
    public void loop(double dt){
        tick(dt);
        collision();
        spawnControl();
        repaint();
    }
    
    @Override
    public void tick(double dt) {
        /////// da update em todo mundo ////////
        player.tick(dt);
        for (int i = 0; i < 6; i++)
            projectileList[i].tick(dt);
        for(Enemy enemy : enemyList)
            enemy.tick(dt);
        /////////////////////////////////////////
        spawnClock += dt;
    }
    
    @Override
    public void paint(Graphics g) {
        super.paint(g); 
        Graphics2D g2d = (Graphics2D) g;
        backGround.render(g2d);
        ///// Renderiza todo mundo /////// Paint = Render
        for (int i = 0; i < 6; i++)
            projectileList[i].render(g2d);
        for(Enemy enemy : enemyList){
            enemy.render(g2d);
        }
        player.render(g2d);
        

        
        
            
    }
    
    public void collision(){  //checo a colisão projetil com inimigo e inimigo com o player
        for(Projectile proj : projectileList){
            for(Enemy enem : enemyList){
                if(proj.getHitbox().intersects(enem.getHitbox())){
                    enemyList.remove(enem);
                    proj.hit();
                }
                if(enem.getY()+ enem.getHeight() > player.getDamageZone() ){
                    enemyList.remove(enem);
                    player.damage();
                    if(player.isDead()){
                        control.changeGameState(GameState.MenuScreen);
                    }
                }
            }
        }    
    }
    
    public abstract void spawnControl();
    
    public void checkPlayerProjectileCollision(){  //Esse metodo é chamado sempre que aperto espaço, ele ve qual projetil vai se mover
        for(Projectile proj : projectileList){
                if(player.getHitbox().intersects(proj.getHitbox())) 
                    proj.startMovement();
        }
    }
    
    @Override
    public void keyDown(KeyEvent e){
        if(e.getKeyCode() == KeyEvent.VK_LEFT || e.getKeyCode() == KeyEvent.VK_RIGHT){
            player.keyPressed(e);
        }else if(e.getKeyCode() == KeyEvent.VK_SPACE){
            checkPlayerProjectileCollision();
        }
    }
    
    @Override
    public void keyUp(KeyEvent e){
        if(e.getKeyCode() == KeyEvent.VK_LEFT || e.getKeyCode() == KeyEvent.VK_RIGHT){
            player.keyReleased(e);
        }
        if(e.getKeyCode() == KeyEvent.VK_R){
            control.changeGameState(GameState.Level1);
        }
        
    }
    
}
