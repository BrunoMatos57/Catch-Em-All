package oopgame.screens;

import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JPanel;

public abstract class ScreenTemplate extends JPanel{
    
    public ScreenTemplate(){  //Interface KeyListener do JPanel. Ela detecta input do usuário a todo momento
        addKeyListener(new KeyListener() {
            
            @Override
            public void keyTyped(KeyEvent e) {
            }
            
            @Override
            public void keyPressed(KeyEvent e) {
                keyDown(e);
            }
            @Override   
            public void keyReleased(KeyEvent e) {
                keyUp(e);
            }
        });
    }
    
    public abstract void loop(double dt);
    
    @Override
    public void paint(Graphics g){
        super.paint(g);
    }
    public abstract void tick(double dt);
    
    public void keyDown(KeyEvent e){ //esse método é chamado sempre que aperto uma tecla
        
    }
    public void keyUp(KeyEvent e){ //é chamado sempre que solto uma tecla
        
    }  
    
}
