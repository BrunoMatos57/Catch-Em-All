package oopgame.choosers;

import java.util.Random;
import oopgame.gameobjects.Enemy;
import oopgame.screens.ScreenTemplate;

public abstract class Wave {
    protected ScreenTemplate screen;
    protected Random rand;
    protected int chooser;
    protected int wave;
    protected int enemyCounter;
    
    public Wave(ScreenTemplate screen){
        this.screen = screen;
        rand = new Random();
        wave = 1;
        enemyCounter = 0;
    }
    
    public int getWave(){
        return wave;
    }
    
    public abstract void checkWaveChanger();
    
    public abstract Enemy getWave1();
    public abstract Enemy getWave2();
    public abstract Enemy getWave3();
    public abstract Enemy getWave4();
    public abstract Enemy getWave5();
    
    
}
