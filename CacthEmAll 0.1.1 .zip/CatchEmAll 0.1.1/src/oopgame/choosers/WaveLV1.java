package oopgame.choosers;

import oopgame.gameobjects.*;
import oopgame.screens.ScreenTemplate;

public class WaveLV1 extends Wave {
    
    public WaveLV1(ScreenTemplate screen){
        super(screen);
    }
    
    @Override
    public void checkWaveChanger() { //pode-se utilizar cadeia de ifs para controlar quantos inimigos por wave;
        enemyCounter++;
        if(enemyCounter > 20){
            wave++;
            enemyCounter = 0;
        }
    }
    
    @Override
    public Enemy getWave1(){
        this.chooser = rand.nextInt(100);
        checkWaveChanger();
        if (chooser < 20){
            return new EnemyNormal("caterpie", screen, EnemyNormal.NORMAL);
        }
        if (chooser < 40){
            return new EnemyNormal("weedle", screen, EnemyNormal.NORMAL);
        }
        if (chooser < 80){
            return new EnemyNormal("blastoise", screen, EnemyNormal.FAST);
        }
        return new EnemyNormal("charmander", screen, EnemyNormal.SLOW);
    }

    @Override
    public Enemy getWave2() {
        this.chooser = rand.nextInt(100);
        checkWaveChanger();
        return new EnemyNormal("charmander", screen, EnemyNormal.FAST);
    }

    @Override
    public Enemy getWave3() {
        this.chooser = rand.nextInt(100);
        checkWaveChanger();
        return new EnemyNormal("charmander", screen, EnemyNormal.NORMAL);
    }

    @Override
    public Enemy getWave4() {
        this.chooser = rand.nextInt(100);
        checkWaveChanger();
        return new EnemyNormal("charmander", screen, EnemyNormal.NORMAL);
    }

    @Override
    public Enemy getWave5() {
        this.chooser = rand.nextInt(100);
        checkWaveChanger();
        return new EnemyNormal("charmander", screen, EnemyNormal.NORMAL);
    }
    
}
